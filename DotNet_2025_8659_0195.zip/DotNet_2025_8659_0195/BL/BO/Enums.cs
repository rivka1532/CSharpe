﻿
namespace BO;
public enum Category { בנים, בנות, תינוקות, אלגנט, אקססוריז }