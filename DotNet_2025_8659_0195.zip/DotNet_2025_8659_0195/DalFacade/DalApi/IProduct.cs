﻿

namespace DalApi
{
    using DO;
    public interface IProduct:ICrud<Product>
    {

    }
}
