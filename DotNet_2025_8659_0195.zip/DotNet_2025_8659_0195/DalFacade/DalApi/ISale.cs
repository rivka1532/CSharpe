﻿
namespace DalApi
{
    using DO;
    public interface ISale:ICrud<Sale>
    {

    }
}
