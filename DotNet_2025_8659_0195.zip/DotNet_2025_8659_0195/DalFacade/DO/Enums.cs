﻿namespace DO;

public enum Category { בנים, בנות, תינוקות, אלגנט, אקססוריז }

